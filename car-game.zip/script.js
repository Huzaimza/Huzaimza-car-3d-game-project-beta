// SCENE SETUP
const scene = new THREE.Scene();
scene.background = new THREE.Color(0x202020);

// CAMERA
const camera = new THREE.PerspectiveCamera(75, window.innerWidth/window.innerHeight, 0.1, 1000);

// RENDERER
const renderer = new THREE.WebGLRenderer({ antialias: true });
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.shadowMap.enabled = true;
document.body.appendChild(renderer.domElement);

// LIGHTING
const ambientLight = new THREE.AmbientLight(0x404040); // soft light
scene.add(ambientLight);

const directionalLight = new THREE.DirectionalLight(0xffffff, 0.5);
directionalLight.position.set(50, 100, 50);
directionalLight.castShadow = true;
scene.add(directionalLight);

// GROUND
const groundGeometry = new THREE.PlaneGeometry(200, 200);
const groundMaterial = new THREE.MeshStandardMaterial({ color: 0x444444 });
const ground = new THREE.Mesh(groundGeometry, groundMaterial);
ground.rotation.x = -Math.PI / 2;
ground.receiveShadow = true;
scene.add(ground);

// CAR
const car = new THREE.Group();
scene.add(car);

const body = new THREE.Mesh(
  new THREE.BoxGeometry(2, 1, 4),
  new THREE.MeshStandardMaterial({ color: 0xff0000 })
);
body.castShadow = true;
car.add(body);

// HEADLIGHTS
const leftLight = new THREE.SpotLight(0xffffff, 1);
leftLight.position.set(0.8, 0.4, -1.9);
leftLight.target.position.set(0.8, 0.4, -4);
leftLight.castShadow = true;
car.add(leftLight);
car.add(leftLight.target);

const rightLight = new THREE.SpotLight(0xffffff, 1);
rightLight.position.set(-0.8, 0.4, -1.9);
rightLight.target.position.set(-0.8, 0.4, -4);
rightLight.castShadow = true;
car.add(rightLight);
car.add(rightLight.target);

// WALLS for crashing
const wallMaterial = new THREE.MeshStandardMaterial({ color: 0x333333 });
const walls = [];
function addWall(x, z, w, h) {
  const wall = new THREE.Mesh(
    new THREE.BoxGeometry(w, 2, h),
    wallMaterial
  );
  wall.position.set(x, 1, z);
  wall.castShadow = true;
  wall.receiveShadow = true;
  scene.add(wall);
  walls.push(wall);
}
addWall(0, -100, 100, 2);
addWall(0, 100, 100, 2);
addWall(-100, 0, 2, 100);
addWall(100, 0, 2, 100);

// CAMERA POSITION
camera.position.set(0, 5, 10);
camera.lookAt(car.position);

// CONTROLS
let speed = 0;
let angle = 0;
const keys = {};

document.addEventListener('keydown', e => keys[e.key] = true);
document.addEventListener('keyup', e => keys[e.key] = false);

function checkCollision(object) {
  const carBox = new THREE.Box3().setFromObject(object);
  for (const wall of walls) {
    const wallBox = new THREE.Box3().setFromObject(wall);
    if (carBox.intersectsBox(wallBox)) return true;
  }
  return false;
}

// ANIMATION
function animate() {
  requestAnimationFrame(animate);

  // Movement
  if (keys["ArrowUp"]) speed = Math.min(speed + 0.01, 0.5);
  if (keys["ArrowDown"]) speed = Math.max(speed - 0.01, -0.3);
  if (keys["ArrowLeft"]) angle += 0.03;
  if (keys["ArrowRight"]) angle -= 0.03;

  // Friction
  speed *= 0.98;

  // Save old position
  const oldPosition = car.position.clone();
  const oldRotation = angle;

  // Move car
  car.rotation.y = angle;
  car.position.x -= Math.sin(angle) * speed;
  car.position.z -= Math.cos(angle) * speed;

  // Collision check
  if (checkCollision(car)) {
    car.position.copy(oldPosition);
    speed = -speed * 0.3;
  }

  // Camera follows
  camera.position.x = car.position.x + Math.sin(angle) * 10;
  camera.position.z = car.position.z + Math.cos(angle) * 10;
  camera.position.y = car.position.y + 5;
  camera.lookAt(car.position);

  renderer.render(scene, camera);
}
animate();
